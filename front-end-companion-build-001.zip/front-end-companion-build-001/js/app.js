
const DATA_URL='data/monday.json';
const toMinutes=t=>{const[h,m]=t.split(':').map(Number);return h*60+m};
const create=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e};
async function start(){
 const data=await (await fetch(DATA_URL)).json();
 const start=toMinutes(data.timeline.start),end=toMinutes(data.timeline.end),span=end-start;
 document.getElementById('pageTitle').textContent=data.meta.day;
 document.getElementById('pageDate').textContent=data.meta.date;
 document.getElementById('storeMeta').textContent=`${data.meta.storeNumber} · ${data.meta.storeName}`;
 document.getElementById('financialWeek').textContent=data.meta.financialWeek;
 document.getElementById('footerStore').textContent=`Store ${data.meta.storeNumber}`;
 document.getElementById('footerWeek').textContent=`W/C ${data.meta.weekCommencing} – ${data.meta.weekEnding}`;
 const head=document.getElementById('timelineHead');
 for(let minute=Math.ceil(start/60)*60;minute<=end;minute+=60){
   const h=create('span','hour-label',String(Math.floor(minute/60)>12?Math.floor(minute/60)-12:Math.floor(minute/60)));
   h.style.left=`${((minute-start)/span)*100}%`;head.appendChild(h);
   if(minute+30<=end){const half=create('span','half-label',':30');half.style.left=`${((minute+30-start)/span)*100}%`;head.appendChild(half)}
 }
 const rows=document.getElementById('staffRows');
 data.staff.forEach(p=>{
   const row=create('div','staff-row'),identity=create('div','identity-card'),badge=create('div','initial-badge',p.initial),details=create('div');
   details.append(create('strong','',p.name),create('span','role',p.role));identity.append(badge,details);
   const track=create('div','timeline-track square-track');
   p.segments.forEach(s=>{
     const left=((toMinutes(s.start)-start)/span)*100;
     if(s.type==='tea'||s.type==='meal'){
       const time=create('span','break-time',s.start);time.style.left=`${left}%`;
       const marker=create('span','break-marker',s.label);marker.style.left=`${left}%`;track.append(time,marker);
     }else{
       const bar=create('span',`deployment-bar ${s.type}`);bar.style.left=`${left}%`;bar.style.width=`${((toMinutes(s.end)-toMinutes(s.start))/span)*100}%`;track.appendChild(bar);
     }
   });
   const ss=create('span','shift-start',p.shiftStart);ss.style.left=`${((toMinutes(p.shiftStart)-start)/span)*100}%`;
   const se=create('span','shift-end',p.shiftEnd);se.style.left=`${((toMinutes(p.shiftEnd)-start)/span)*100}%`;
   track.append(ss,se);row.append(identity,track);rows.appendChild(row);
 });
 const d=document.getElementById('scoDemandTrack');
 data.scoDemand.forEach(({time,count})=>{const base=((toMinutes(time)-start)/span)*100;for(let i=0;i<count;i++){const dot=create('span','demand-dot');dot.style.left=`calc(${base}% + ${(i-(count-1)/2)*8}px)`;d.appendChild(dot)}});
}
document.getElementById('printButton').onclick=()=>window.print();
start().catch(console.error);
